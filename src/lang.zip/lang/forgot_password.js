const words = {
  english: {
    log_in: "Log in",
    Login_with_EDS: "ERI bilan tizimga kirish",
    password: "Password",
    remember: "Remember Me",
  },
  russian: {
    Password_recovery: "Восстановление пароля",
    Enter_email_for_new_passsword:
      "Введите действующий email, на него будет выслан ваш новый пароль",
    Email: "Email",
    Enter_your_email: "Введите ваше e-mail...",
    Restore: "Восстановить",
  },
  uzbek: {
    Password_recovery: "Parolni tiklash",
    Enter_email_for_new_passsword:
      "Amaldagi  elektron pochta manzilini kiriting, unga yangi parolingiz yuboriladi",
    Email: "Email",
    Enter_your_email: "Elektron pochtangizni kiriting...",
    Restore: "Qayta tiklash",
  },
};
